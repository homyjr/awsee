from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Customer)
admin.site.register(Product)
admin.site.register(Order)
admin.site.register(Orderitem)
admin.site.register(Shippingaddress)
admin.site.register(Myorder)
admin.site.register(Categories)
admin.site.register(Review)